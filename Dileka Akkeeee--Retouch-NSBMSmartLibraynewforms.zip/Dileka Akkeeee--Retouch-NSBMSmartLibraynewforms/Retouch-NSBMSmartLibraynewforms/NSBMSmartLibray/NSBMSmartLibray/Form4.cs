﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace NSBMSmartLibray
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }

        

        

       

       

        

        

       

       

        

       

        

        private void button12_Click(object sender, EventArgs e)
        {
            Form6 openForm = new Form6();
            openForm.Show();
            Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 openForm = new Form3();
            openForm.Show();
            Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form7 openForm = new Form7();
            openForm.Show();
            Visible = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form8 openForm = new Form8();
            openForm.Show();
            Visible = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form9 openForm = new Form9();
            openForm.Show();
            Visible = false;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form10 openForm = new Form10();
            openForm.Show();
            Visible = false;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form11 openForm = new Form11();
            openForm.Show();
            Visible = false;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form12 openForm = new Form12();
            openForm.Show();
            Visible = false;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Form13 openForm = new Form13();
            openForm.Show();
            Visible = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Form14 openForm = new Form14();
            openForm.Show();
            Visible = false;
        }

        private void button11_Click(object sender, EventArgs e)
        {
            Form15 openForm = new Form15();
            openForm.Show();
            Visible = false;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Form16 openForm = new Form16();
            openForm.Show();
            Visible = false;
        }

        private void button14_Click(object sender, EventArgs e)
        {
            Form17 openForm = new Form17("Translation");
            openForm.ShowDialog();
            Visible = false;

        }
    }
}
